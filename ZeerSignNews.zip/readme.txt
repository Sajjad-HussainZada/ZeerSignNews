import the ZeerSignNews database to your local host with the name wordpress1 (name in phpmyadmin is wordpress1 too)

then extract the ZeerSignNews theme folder to your theme folder

username and password

Sajjad

&ZJf5nkjG0z2A%jjugoVN@9(